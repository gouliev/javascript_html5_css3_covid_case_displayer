echo "This works fine!"
echo "Testing an .sh file in JS" #apparently you can use nodeJS to execute shell commands
#Will consider using this for my OS assignment for the "extra bonus point section to implement something not asked"




#DELETE FILE BEFORE SUBMISSION